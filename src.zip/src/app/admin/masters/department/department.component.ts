import {
  trigger,
  state,
  style,
  transition,
  animate,
} from '@angular/animations';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { EmployeeService } from 'src/app/core/services/Employee.service';
import { JwtService } from 'src/app/core/services/jwt.service';
import { LoginService } from 'src/app/core/services/login.service';
import { NotificationService } from 'src/app/core/services/notificationnew.service';
import { DepartmentService } from 'src/app/core/services/department.service';
import { CommonModule } from '@angular/common';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgSelectModule } from '@ng-select/ng-select';

export interface DepartmentItem {
  id: number | string;
  name: string;
  status?: boolean | number | string;
  updated_at?: string;
  is_active?: boolean | number | string;
  [key: string]: any;
}

@Component({
  selector: 'app-department',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    NgxPaginationModule,
    NgSelectModule,
  ],
  templateUrl: './department.component.html',
  styleUrl: './department.component.scss',
  animations: [
    trigger('succesfullyMesaage', [
      state(
        'void',
        style({
          transform: 'translateX(-30%)',
          opacity: 0,
        }),
      ),
      transition(':enter, :leave', [
        animate('0.8s cubic-bezier(0.68, -0.55, 0.27, 1.55)'),
      ]),
    ]),
    trigger('slideIn', [
      state(
        'void',
        style({
          transform: 'translateX(100%)',
          opacity: 0,
        }),
      ),
      transition(':enter', [
        animate(
          '0.5s ease-out',
          style({
            transform: 'translateX(0)', // Final position for slide-in effect
            opacity: 1, // Final opacity
          }),
        ),
      ]),
    ]),

    trigger('fadeIn', [
      state(
        'void',
        style({
          opacity: 0,
          transform: 'scale(0.5)', // Start with smaller size
        }),
      ),
      transition(':enter', [
        animate(
          '0.5s ease-out',
          style({
            opacity: 1,
            transform: 'scale(1)', // Final size
          }),
        ),
      ]),
    ]),
  ],
})
export class DepartmentComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  showreset: boolean = false; // Reintroduced for reset button visibility
  searchbarform!: FormGroup;
  createDepartmentForm!: FormGroup;
  updateDepartmentForm!: FormGroup;
  viewDepartmentForm!: FormGroup;
  tableSize: number = 10;
  tableSizes: number[] = [10, 20, 50, 100];
  totalRecords: number = 0;
  page: number = 1;
  createDepartmentOpen: boolean = false;
  updateDepartmentOpen: boolean = false;
  viewDepartmentOpen: boolean = false;
  selectedDepartment: DepartmentItem | null = null;
  departmentList: DepartmentItem[] = [];

  onTableSizeChange(event: Event | number): void {
    if (typeof event === 'number') {
      this.tableSize = event;
    } else if (event && event.target) {
      this.tableSize = Number((event.target as HTMLInputElement).value);
    }
    this.page = 1;
    this.GetDepartmentFun();
  }

  constructor(
    private formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private jwtService: JwtService,
    private notificationService: NotificationService,
    private loginService: LoginService,
    private departmentService: DepartmentService,
  ) {}

  searchfun() {
    const searchText = this.searchbarform.get('searchbar')?.value || '';
    this.showreset = searchText.trim().length > 0;
    this.GetDepartmentFun();
  }

  resetsearchbar() {
    this.searchbarform.get('searchbar')?.reset(); // Clear the search input
    this.showreset = false; // Hide reset button
    this.page = 1; // Reset to first page
    this.GetDepartmentFun(); // Reload data without search
  }
  uuserId: any;
  ngOnInit(): void {
    this.uuserId = this.jwtService.getpanelUserId();
    this.searchbarform = this.formBuilder.group({
      searchbar: [''],
    });

    this.createDepartmentForm = this.formBuilder.group({
      Name: ['', [Validators.required]],
    });

    this.updateDepartmentForm = this.formBuilder.group({
      Name: ['', [Validators.required, Validators.minLength(2)]],
    });

    this.viewDepartmentForm = this.formBuilder.group({
      Name: [''],
    });
    this.GetDepartmentFun();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

  table_heading = [
    {
      heading0: 'Serial No.',
      heading1: 'Name',
      heading2: 'Status',
      heading3: 'Action',
    },
  ];

  currentDepartmentId: any;

  OpenEditModal(user: any): void {
    this.currentDepartmentId = user.id;
    this.updateDepartmentOpen = true;
    // this.updateDepartmentForm.patchValue({ Name: user.name });
    this.GetupdateDepartmentbyid(this.currentDepartmentId);
  }

  openviewModal(user: any): void {
    this.viewDepartmentOpen = true;
    this.currentDepartmentId = user.id;
    this.selectedDepartment = null;

    this.departmentService.getDepartmentById(user.id).pipe(takeUntil(this.destroy$)).subscribe({
      next: (response: any) => {
        if (response.status === 200) {
          this.selectedDepartment = response.data;
          this.viewDepartmentForm.patchValue({ Name: response.data.name });
        }
      },
      error: (error: any) => {
        console.error('Error fetching department details:', error);
      }
    });
  }


  GetupdateDepartmentbyid(userId: any) {
    this.departmentService.getDepartmentById(userId).pipe(takeUntil(this.destroy$)).subscribe({
      next: (response: any) => {
        if (response.status === 200) {
          this.fillformdate(response.data);
        }
      },
      error: (error: any) => {
        console.error('Error fetching department details:', error);
      }
    });
  }

  fillformdate(response: any) {
    if (this.updateDepartmentForm) {
      this.updateDepartmentForm.patchValue({
        Name: response.name
      });
    }
  }
  updateDepartment() {
    if (this.updateDepartmentForm.valid) {
      const name = this.updateDepartmentForm.get('Name')?.value;

      const formData = new FormData();
      formData.append('name', name);
      formData.append('_method', 'PUT');

      this.departmentService.updateDepartment(this.currentDepartmentId, formData).pipe(takeUntil(this.destroy$)).subscribe({
        next: (response: any) => {
          if (response.status === 200 || response.status === 201) {
            this.closeModal();
            this.notificationService.show(response.message || 'Department updated successfully', 'success', 3000);
            this.GetDepartmentFun();
          } else {
            this.notificationService.show(
              response.message || response.error || 'Something went wrong',
              'error',
              3000,
            );
          }
        },
        error: (error: any) => {
          console.error('Update Department failed:', error);
          let errorMsg = '';
          if (typeof error === 'string') {
            errorMsg = error.includes('Message:') ? error.split('Message:')[1].trim() : error;
          } else {
            errorMsg = error.message || error.error?.message || 'Something went wrong';
          }
          this.notificationService.show(errorMsg, 'error', 3000);
        }
      });
    } else {
      this.updateDepartmentForm.markAllAsTouched();
    }
  }

  onTableDataChange(event: number) {
    this.page = event;
    this.GetDepartmentFun();
  }

  closeModal() {
    this.updateDepartmentOpen = false;
    this.createDepartmentOpen = false;
    this.viewDepartmentOpen = false;
    this.selectedDepartment = null;
    this.createDepartmentForm.reset();
  }

  openAddModal() {
    this.createDepartmentOpen = true;
  }
  errorMessage: any;
  createDepartment() {
    if (this.createDepartmentForm.valid) {
      const name = this.createDepartmentForm.get('Name')?.value;

      const formData = new FormData();
      formData.append('name', name);

      this.departmentService.createDepartment(formData).pipe(takeUntil(this.destroy$)).subscribe({
        next: (response: any) => {
          if (response.status === 200 || response.status === 201) {
            this.closeModal();
            this.notificationService.show(response.message || 'Department created successfully', 'success', 3000);
            this.GetDepartmentFun();
          } else {
            this.notificationService.show(
              response.message || response.error || 'Something went wrong',
              'error',
              3000,
            );
          }
        },
        error: (error) => {
          console.error('Create Department failed:', error);
          let errorMsg = '';
          if (typeof error === 'string') {
            errorMsg = error.includes('Message:') ? error.split('Message:')[1].trim() : error;
          } else {
            errorMsg = error.message || error.error?.message || 'Something went wrong';
          }
          this.errorMessage = errorMsg; // Display error message
          this.notificationService.show(this.errorMessage, 'error', 3000);
        },
      });
    } else {
      this.createDepartmentForm.markAllAsTouched();
    }
  }

  GetDepartmentFun() {
    const searchText = this.searchbarform?.get('searchbar')?.value || '';

    this.departmentService
      .getDepartments(this.tableSize, this.page, searchText)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response.status === 200) {
            this.departmentList = response.data;
            this.totalRecords = response.pagination?.total || response.data.length;
          } else {
            console.error('Failed to fetch departments:', response.message);
          }
        },
        error: (error: any) => {
          console.error('Error fetching departments:', error);
        }
      });
  }

  async Status(id: number | string, status: boolean | number | string) {
    const department = this.departmentList?.find((d: DepartmentItem) => d.id === id);
    if (!department) return;

    const formData = new FormData();
    formData.append('_method', 'PATCH');
    formData.append('status', status.toString());

    this.departmentService.updateDepartmentStatus(id, formData).pipe(takeUntil(this.destroy$)).subscribe({
      next: (response: any) => {
        if (response.status === 200 || response.status === 201) {
          this.notificationService.show(
            response.message || `Department status updated successfully`,
            'success',
            3000
          );
          this.GetDepartmentFun();
        } else {
          this.notificationService.show(
            response.message || response.error || 'Failed to update status',
            'error',
            3000
          );
        }
      },
      error: (error: any) => {
        console.error('Status update failed:', error);
        let errorMsg = '';
        if (typeof error === 'string') {
          errorMsg = error.includes('Message:') ? error.split('Message:')[1].trim() : error;
        } else {
          errorMsg = error.message || error.error?.message || 'Something went wrong';
        }
        this.notificationService.show(errorMsg, 'error', 3000);
      }
    });
  }
}
